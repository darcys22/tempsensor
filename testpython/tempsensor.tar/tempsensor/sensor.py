import Adafruit_DHT
import time

import config

import grpc

import temp_pb2
import temp_pb2_grpc
 
DHT_SENSOR = Adafruit_DHT.DHT11
 
with grpc.insecure_channel('192.168.1.98:30051') as channel:
    while True:
        hum, tmp = Adafruit_DHT.read(DHT_SENSOR, config.DHT_PIN)

        if hum is not None and tmp is not None:
            hiCel = Adafruit_DHT.computeHeatIndex(tmp, hum, false);
            stub = temp_pb2_grpc.TransactorStub(channel)
            response = stub.SendTemp(temp_pb2.TempEvent(
                deviceId = config.deviceId,
                eventId = config.eventId,
                humidity = hum,
                tempCel = tmp,
                heatIdxCel = hiCel
                ))

        time.sleep(3);
