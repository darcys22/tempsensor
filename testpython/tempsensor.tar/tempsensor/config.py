#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ##### sensor.py Config
# Edit starts here

deviceId = 12
eventId = 100

DHT_PIN = 4

# Edit ends here

# ##### /sensor.py Config
